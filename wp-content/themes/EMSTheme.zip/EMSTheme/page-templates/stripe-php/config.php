<?php

/*
define('SECRET_KEY', 'sk_test_MBsbptinTMAnCDlnrB6sFpSc');
define('PUBLIC_KEY', 'pk_test_hY0Pm2czYuJhWqNPNwFFeZbp');
*/

define('SECRET_KEY', 'sk_live_7zcQk9iyOu7J2oE6qVXDfz4P');
define('PUBLIC_KEY', 'pk_live_UA0vecpcmBuunRGSw7rMiKSU');
?>