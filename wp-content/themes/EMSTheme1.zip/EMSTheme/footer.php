<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package understrap
 */

$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="wrapper-footer">
	<div class="<?php echo esc_html( $container ); ?> whitetextbox">
		<div class="row">
			<div class="col-sm-6 col-md-3">
            	<?php wp_nav_menu(
                    array(
                        'theme_location'  => 'footer1',
                        'container_class' => '',
                        'container_id'    => '',
                        'menu_class'      => '',
                        'fallback_cb'     => '',
                        'menu_id'         => 'footer-menu-1',
                    ) ); ?>
            </div>
            <div class="col-sm-6 col-md-3">
            	<?php wp_nav_menu(
                    array(
                        'theme_location'  => 'footer2',
                        'container_class' => '',
                        'container_id'    => '',
                        'menu_class'      => '',
                        'fallback_cb'     => '',
                        'menu_id'         => 'footer-menu-2',
                    ) ); ?>
            </div>
            <div class="col-sm-6 col-md-3">
            	<?php wp_nav_menu(
                    array(
                        'theme_location'  => 'footer3',
                        'container_class' => '',
                        'container_id'    => '',
                        'menu_class'      => '',
                        'fallback_cb'     => '',
                        'menu_id'         => 'footer-menu-3',
                    ) ); ?>
            </div>
            <div class="col-sm-6 col-md-3">
            	<?php get_sidebar( 'footer4' ); ?>
            </div>
			<div class="col-md-12 mt-3">
				<footer class="site-footer" id="colophon">
					<div class="site-info">
						<?php printf( __( '&copy; Send My Stuff - All Rights Reserved', 'understrap' ) ); ?>
						<span class="sep"> | </span>
						<a href="<?php echo esc_url( __( 'https://wptweaks.co.uk/', 'understrap' ) ); ?>"><?php printf( __( 'WordPress Support &amp; Maintenance', 'understrap' ) ); ?></a>
					</div><!-- .site-info -->
				</footer><!-- #colophon -->
			</div><!--col end -->
		</div><!-- row end -->
	</div><!-- container end -->
</div><!-- wrapper end -->
</div><!-- #page -->

<?php get_sidebar( 'footerfull' ); ?>

<?php wp_footer(); ?>

</body>

</html>
