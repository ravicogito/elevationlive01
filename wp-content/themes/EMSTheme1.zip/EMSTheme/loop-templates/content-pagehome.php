<?php
/**
 * Partial template for content in homepage.php
 *
 * @package understrap
 */

?>
<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">

	<header class="home-header">

		<?php the_title( '<div class="entry-title text-uppercase text-center">', '</div>' ); 
		$subtitle = get_post_meta($post->ID, 'Subtitle', $single = true);
		$subsubtitle = get_post_meta($post->ID, 'Subsubtitle', $single = true);
		if($subtitle !== '') echo '<h2 class="text-center">' . $subtitle . '</h2>';
		if($subsubtitle !== '') echo '<h2 class="text-center">' . $subsubtitle . '</h2>';
		?>

	</header><!-- .entry-header -->
    
    <div class="quick-quote-container">
    	<form action="/quote" class="form-inline" id="quick-quote" method="post" novalidate="novalidate">
            <input name="__RequestVerificationToken" type="hidden" >
                <label for="Origin_CountryIso" class="col-md-2">Send From</label>
                <select id="Origin_CountryIso" name="Origin.CountryIso" class="col-md-4 custom-select" placeholder="select a country" autocomplete="false" data-bind="value: CountryIso" data-val="true" data-val-required="Country is required." tabindex="-1" title="Send From">
                    <optgroup label="Most Popular">
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain" selected>UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="IE" data-alt="">Ireland</option>
                    </optgroup>
                    <optgroup label="A-Z">
                        <option value="AF" data-alt="">Afghanistan</option>
                        <option value="AL" data-alt="">Albania</option>
                        <option value="DZ" data-alt="">Algeria</option>
                        <option value="AS" data-alt="">American Samoa</option>
                        <option value="AD" data-alt="">Andorra</option>
                        <option value="AO" data-alt="">Angola</option>
                        <option value="AI" data-alt="">Anguilla</option>
                        <option value="AG" data-alt="">Antigua and Barbuda</option>
                        <option value="AM" data-alt="">Armenia</option>
                        <option value="AW" data-alt="">Aruba</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="AT" data-alt="">Austria</option>
                        <option value="AZ" data-alt="">Azerbaijan</option>
                        <option value="BS" data-alt="">Bahamas</option>
                        <option value="BH" data-alt="">Bahrain</option>
                        <option value="BD" data-alt="">Bangladesh</option>
                        <option value="BB" data-alt="">Barbados</option>
                        <option value="BY" data-alt="">Belarus</option>
                        <option value="BE" data-alt="">Belgium</option>
                        <option value="BZ" data-alt="">Belize</option>
                        <option value="BJ" data-alt="">Benin</option>
                        <option value="BM" data-alt="">Bermuda</option>
                        <option value="BT" data-alt="">Bhutan</option>
                        <option value="BO" data-alt="">Bolivia</option>
                        <option value="BA" data-alt="">Bosnia and Herzegovina</option>
                        <option value="BW" data-alt="">Botswana</option>
                        <option value="BR" data-alt="">Brazil</option>
                        <option value="BN" data-alt="">Brunei Darussalam</option>
                        <option value="BG" data-alt="">Bulgaria</option>
                        <option value="BF" data-alt="">Burkina Faso</option>
                        <option value="BI" data-alt="">Burundi</option>
                        <option value="KH" data-alt="">Cambodia</option>
                        <option value="CM" data-alt="">Cameroon</option>
                        <option value="CA" data-alt="">Canada</option>
                        <option value="CV" data-alt="">Cape Verde</option>
                        <option value="KY" data-alt="">Cayman Islands</option>
                        <option value="CF" data-alt="">Central African Republic</option>
                        <option value="TD" data-alt="">Chad</option>
                        <option value="CL" data-alt="">Chile</option>
                        <option value="CN" data-alt="">China</option>
                        <option value="CO" data-alt="">Colombia</option>
                        <option value="KM" data-alt="">Comoros</option>
                        <option value="CG" data-alt="">Congo</option>
                        <option value="CK" data-alt="">Cook Islands</option>
                        <option value="CR" data-alt="">Costa Rica</option>
                        <option value="CI" data-alt="">Cote D'Ivoire</option>
                        <option value="HR" data-alt="">Croatia</option>
                        <option value="CU" data-alt="">Cuba</option>
                        <option value="CY" data-alt="">Cyprus</option>
                        <option value="CZ" data-alt="">Czech Republic</option>
                        <option value="DK" data-alt="">Denmark</option>
                        <option value="DJ" data-alt="">Djibouti</option>
                        <option value="DM" data-alt="">Dominica</option>
                        <option value="DO" data-alt="">Dominican Republic</option>
                        <option value="EC" data-alt="">Ecuador</option>
                        <option value="EG" data-alt="">Egypt</option>
                        <option value="SV" data-alt="">El Salvador</option>
                        <option value="GQ" data-alt="">Equatorial Guinea</option>
                        <option value="ER" data-alt="">Eritrea</option>
                        <option value="EE" data-alt="">Estonia</option>
                        <option value="ET" data-alt="">Ethiopia</option>
                        <option value="FK" data-alt="">Falkland Islands (Malvinas)</option>
                        <option value="FJ" data-alt="">Fiji</option>
                        <option value="FI" data-alt="">Finland</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="GF" data-alt="">French Guiana</option>
                        <option value="GA" data-alt="">Gabon</option>
                        <option value="GM" data-alt="">Gambia</option>
                        <option value="GE" data-alt="">Georgia</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="GH" data-alt="">Ghana</option>
                        <option value="GI" data-alt="">Gibraltar</option>
                        <option value="GR" data-alt="">Greece</option>
                        <option value="GD" data-alt="">Grenada</option>
                        <option value="GP" data-alt="">Guadeloupe</option>
                        <option value="GU" data-alt="">Guam</option>
                        <option value="GT" data-alt="">Guatemala</option>
                        <option value="GG" data-alt="UK United Kingdom England Great Britain Channel Islands">Guernsey</option>
                        <option value="GN" data-alt="">Guinea</option>
                        <option value="GW" data-alt="">Guinea-Bissau</option>
                        <option value="HT" data-alt="">Haiti</option>
                        <option value="HN" data-alt="">Honduras</option>
                        <option value="HK" data-alt="">Hong Kong</option>
                        <option value="HU" data-alt="">Hungary</option>
                        <option value="IS" data-alt="">Iceland</option>
                        <option value="IN" data-alt="">India</option>
                        <option value="ID" data-alt="">Indonesia</option>
                        <option value="IR" data-alt="">Iran, Islamic Republic of</option>
                        <option value="IQ" data-alt="">Iraq</option>
                        <option value="IE" data-alt="">Ireland</option>
                        <option value="IL" data-alt="">Israel</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="JM" data-alt="">Jamaica</option>
                        <option value="JP" data-alt="">Japan</option>
                        <option value="JE" data-alt="UK United Kingdom England Great Britain Channel Islands">Jersey</option>
                        <option value="JO" data-alt="">Jordan</option>
                        <option value="KZ" data-alt="">Kazakhstan</option>
                        <option value="KE" data-alt="">Kenya</option>
                        <option value="KP" data-alt="">Korea, Democratic People's Republic of</option>
                        <option value="KR" data-alt="South Korea">Korea, Republic of</option>
                        <option value="KW" data-alt="">Kuwait</option>
                        <option value="KG" data-alt="">Kyrgyzstan</option>
                        <option value="LA" data-alt="">Lao People's Democratic Republic</option>
                        <option value="LV" data-alt="">Latvia</option>
                        <option value="LB" data-alt="">Lebanon</option>
                        <option value="LS" data-alt="">Lesotho</option>
                        <option value="LR" data-alt="">Liberia</option>
                        <option value="LY" data-alt="">Libyan Arab Jamahiriya</option>
                        <option value="LI" data-alt="">Liechtenstein</option>
                        <option value="LT" data-alt="">Lithuania</option>
                        <option value="LU" data-alt="">Luxembourg</option>
                        <option value="MO" data-alt="">Macao</option>
                        <option value="MK" data-alt="">Macedonia, the Former Yugoslav Republic of</option>
                        <option value="MG" data-alt="">Madagascar</option>
                        <option value="MW" data-alt="">Malawi</option>
                        <option value="MY" data-alt="">Malaysia</option>
                        <option value="MV" data-alt="">Maldives</option>
                        <option value="ML" data-alt="">Mali</option>
                        <option value="MT" data-alt="">Malta</option>
                        <option value="MH" data-alt="">Marshall Islands</option>
                        <option value="MQ" data-alt="">Martinique</option>
                        <option value="MR" data-alt="">Mauritania</option>
                        <option value="MU" data-alt="">Mauritius</option>
                        <option value="YT" data-alt="">Mayotte</option>
                        <option value="MX" data-alt="">Mexico</option>
                        <option value="MD" data-alt="">Moldova, Republic of</option>
                        <option value="MC" data-alt="">Monaco</option>
                        <option value="MN" data-alt="">Mongolia</option>
                        <option value="MS" data-alt="">Montserrat</option>
                        <option value="MA" data-alt="">Morocco</option>
                        <option value="MZ" data-alt="">Mozambique</option>
                        <option value="MM" data-alt="">Myanmar</option>
                        <option value="NA" data-alt="">Namibia</option>
                        <option value="NR" data-alt="">Nauru</option>
                        <option value="NP" data-alt="">Nepal</option>
                        <option value="NL" data-alt="">Netherlands</option>
                        <option value="AN" data-alt="">Netherlands Antilles</option>
                        <option value="NC" data-alt="">New Caledonia</option>
                        <option value="NZ" data-alt="">New Zealand</option>
                        <option value="NI" data-alt="">Nicaragua</option>
                        <option value="NE" data-alt="">Niger</option>
                        <option value="NG" data-alt="">Nigeria</option>
                        <option value="NU" data-alt="">Niue</option>
                        <option value="NO" data-alt="">Norway</option>
                        <option value="OM" data-alt="">Oman</option>
                        <option value="PK" data-alt="">Pakistan</option>
                        <option value="PW" data-alt="">Palau</option>
                        <option value="PA" data-alt="">Panama</option>
                        <option value="PG" data-alt="">Papua New Guinea</option>
                        <option value="PY" data-alt="">Paraguay</option>
                        <option value="PE" data-alt="">Peru</option>
                        <option value="PH" data-alt="">Philippines</option>
                        <option value="PL" data-alt="">Poland</option>
                        <option value="PT" data-alt="">Portugal</option>
                        <option value="PR" data-alt="">Puerto Rico</option>
                        <option value="QA" data-alt="">Qatar</option>
                        <option value="RE" data-alt="">Reunion</option>
                        <option value="RO" data-alt="">Romania</option>
                        <option value="RW" data-alt="">Rwanda</option>
                        <option value="KN" data-alt="">Saint Kitts and Nevis</option>
                        <option value="VC" data-alt="">Saint Vincent and the Grenadines</option>
                        <option value="WS" data-alt="">Samoa</option>
                        <option value="ST" data-alt="">Sao Tome and Principe</option>
                        <option value="SA" data-alt="">Saudi Arabia</option>
                        <option value="SN" data-alt="">Senegal</option>
                        <option value="SC" data-alt="">Seychelles</option>
                        <option value="SL" data-alt="">Sierra Leone</option>
                        <option value="SG" data-alt="">Singapore</option>
                        <option value="SK" data-alt="">Slovakia</option>
                        <option value="SI" data-alt="">Slovenia</option>
                        <option value="SB" data-alt="">Solomon Islands</option>
                        <option value="SO" data-alt="">Somalia</option>
                        <option value="ZA" data-alt="">South Africa</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="LK" data-alt="">Sri Lanka</option>
                        <option value="SD" data-alt="">Sudan</option>
                        <option value="SR" data-alt="">Suriname</option>
                        <option value="SZ" data-alt="">Swaziland</option>
                        <option value="SE" data-alt="">Sweden</option>
                        <option value="CH" data-alt="">Switzerland</option>
                        <option value="SY" data-alt="">Syrian Arab Republic</option>
                        <option value="TW" data-alt="">Taiwan, Province of China</option>
                        <option value="TJ" data-alt="">Tajikistan</option>
                        <option value="TZ" data-alt="">Tanzania, United Republic of</option>
                        <option value="TH" data-alt="">Thailand</option>
                        <option value="TG" data-alt="">Togo</option>
                        <option value="TO" data-alt="">Tonga</option>
                        <option value="TT" data-alt="">Trinidad and Tobago</option>
                        <option value="TC" data-alt="">Turks and Caicos Islands</option>
                        <option value="TV" data-alt="">Tuvalu</option>
                        <option value="UG" data-alt="">Uganda</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain" selected="selected">UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="UA" data-alt="">Ukraine</option>
                        <option value="AE" data-alt="uae">United Arab Emirates</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="UY" data-alt="">Uruguay</option>
                        <option value="UZ" data-alt="">Uzbekistan</option>
                        <option value="VU" data-alt="">Vanuatu</option>
                        <option value="VE" data-alt="">Venezuela</option>
                        <option value="VN" data-alt="">Viet Nam</option>
                        <option value="VG" data-alt="">Virgin Islands, British</option>
                        <option value="VI" data-alt="">Virgin Islands, U.s.</option>
                        <option value="YE" data-alt="">Yemen</option>
                        <option value="ZM" data-alt="">Zambia</option>
                        <option value="ZW" data-alt="">Zimbabwe</option>
                    </optgroup>
                </select>
    
                <label class="col-md-1" for="Destination_CountryIso">To</label>
                <select id="Destination_CountryIso" name="Destination.CountryIso" class="col-md-4 custom-select" placeholder="select a country" autocomplete="false" data-bind="value: CountryIso" data-val="true" data-val-required="Country is required." tabindex="-1" title="To">
                	<option value="">select a country</option>
                    <optgroup label="Most Popular">
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="IE" data-alt="">Ireland</option>
                    </optgroup>
                    <optgroup label="A-Z">
                        <option value="AF" data-alt="">Afghanistan</option>
                        <option value="DZ" data-alt="">Algeria</option>
                        <option value="AS" data-alt="">American Samoa</option>
                        <option value="AO" data-alt="">Angola</option>
                        <option value="AI" data-alt="">Anguilla</option>
                        <option value="AM" data-alt="">Armenia</option>
                        <option value="AW" data-alt="">Aruba</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="AT" data-alt="">Austria</option>
                        <option value="AZ" data-alt="">Azerbaijan</option>
                        <option value="BS" data-alt="">Bahamas</option>
                        <option value="BH" data-alt="">Bahrain</option>
                        <option value="BD" data-alt="">Bangladesh</option>
                        <option value="BB" data-alt="">Barbados</option>
                        <option value="BE" data-alt="">Belgium</option>
                        <option value="BZ" data-alt="">Belize</option>
                        <option value="BJ" data-alt="">Benin</option>
                        <option value="BM" data-alt="">Bermuda</option>
                        <option value="BT" data-alt="">Bhutan</option>
                        <option value="BO" data-alt="">Bolivia</option>
                        <option value="BW" data-alt="">Botswana</option>
                        <option value="BR" data-alt="">Brazil</option>
                        <option value="BN" data-alt="">Brunei Darussalam</option>
                        <option value="BG" data-alt="">Bulgaria</option>
                        <option value="BF" data-alt="">Burkina Faso</option>
                        <option value="BI" data-alt="">Burundi</option>
                        <option value="KH" data-alt="">Cambodia</option>
                        <option value="CM" data-alt="">Cameroon</option>
                        <option value="CA" data-alt="">Canada</option>
                        <option value="CV" data-alt="">Cape Verde</option>
                        <option value="CF" data-alt="">Central African Republic</option>
                        <option value="TD" data-alt="">Chad</option>
                        <option value="CL" data-alt="">Chile</option>
                        <option value="CO" data-alt="">Colombia</option>
                        <option value="CG" data-alt="">Congo</option>
                        <option value="CK" data-alt="">Cook Islands</option>
                        <option value="CR" data-alt="">Costa Rica</option>
                        <option value="CI" data-alt="">Cote D'Ivoire</option>
                        <option value="HR" data-alt="">Croatia</option>
                        <option value="CU" data-alt="">Cuba</option>
                        <option value="CY" data-alt="">Cyprus</option>
                        <option value="CZ" data-alt="">Czech Republic</option>
                        <option value="DK" data-alt="">Denmark</option>
                        <option value="DJ" data-alt="">Djibouti</option>
                        <option value="DM" data-alt="">Dominica</option>
                        <option value="DO" data-alt="">Dominican Republic</option>
                        <option value="EC" data-alt="">Ecuador</option>
                        <option value="EG" data-alt="">Egypt</option>
                        <option value="SV" data-alt="">El Salvador</option>
                        <option value="GQ" data-alt="">Equatorial Guinea</option>
                        <option value="ER" data-alt="">Eritrea</option>
                        <option value="EE" data-alt="">Estonia</option>
                        <option value="ET" data-alt="">Ethiopia</option>
                        <option value="FK" data-alt="">Falkland Islands (Malvinas)</option>
                        <option value="FJ" data-alt="">Fiji</option>
                        <option value="FI" data-alt="">Finland</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="GF" data-alt="">French Guiana</option>
                        <option value="GA" data-alt="">Gabon</option>
                        <option value="GM" data-alt="">Gambia</option>
                        <option value="GE" data-alt="">Georgia</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="GH" data-alt="">Ghana</option>
                        <option value="GR" data-alt="">Greece</option>
                        <option value="GD" data-alt="">Grenada</option>
                        <option value="GP" data-alt="">Guadeloupe</option>
                        <option value="GU" data-alt="">Guam</option>
                        <option value="GT" data-alt="">Guatemala</option>
                        <option value="GG" data-alt="UK United Kingdom England Great Britain Channel Islands">Guernsey</option>
                        <option value="GW" data-alt="">Guinea-Bissau</option>
                        <option value="GY" data-alt="">Guyana</option>
                        <option value="HT" data-alt="">Haiti</option>
                        <option value="HN" data-alt="">Honduras</option>
                        <option value="HK" data-alt="">Hong Kong</option>
                        <option value="HU" data-alt="">Hungary</option>
                        <option value="IS" data-alt="">Iceland</option>
                        <option value="IN" data-alt="">India</option>
                        <option value="ID" data-alt="">Indonesia</option>
                        <option value="IR" data-alt="">Iran, Islamic Republic of</option>
                        <option value="IQ" data-alt="">Iraq</option>
                        <option value="IE" data-alt="">Ireland</option>
                        <option value="IL" data-alt="">Israel</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="JM" data-alt="">Jamaica</option>
                        <option value="JP" data-alt="">Japan</option>
                        <option value="JE" data-alt="UK United Kingdom England Great Britain Channel Islands">Jersey</option>
                        <option value="JO" data-alt="">Jordan</option>
                        <option value="KZ" data-alt="">Kazakhstan</option>
                        <option value="KE" data-alt="">Kenya</option>
                        <option value="KI" data-alt="">Kiribati</option>
                        <option value="KR" data-alt="South Korea">Korea, Republic of</option>
                        <option value="KW" data-alt="">Kuwait</option>
                        <option value="KG" data-alt="">Kyrgyzstan</option>
                        <option value="LV" data-alt="">Latvia</option>
                        <option value="LB" data-alt="">Lebanon</option>
                        <option value="LS" data-alt="">Lesotho</option>
                        <option value="LR" data-alt="">Liberia</option>
                        <option value="LT" data-alt="">Lithuania</option>
                        <option value="LU" data-alt="">Luxembourg</option>
                        <option value="MO" data-alt="">Macao</option>
                        <option value="MG" data-alt="">Madagascar</option>
                        <option value="MW" data-alt="">Malawi</option>
                        <option value="MY" data-alt="">Malaysia</option>
                        <option value="MV" data-alt="">Maldives</option>
                        <option value="MT" data-alt="">Malta</option>
                        <option value="MH" data-alt="">Marshall Islands</option>
                        <option value="MQ" data-alt="">Martinique</option>
                        <option value="MR" data-alt="">Mauritania</option>
                        <option value="MU" data-alt="">Mauritius</option>
                        <option value="YT" data-alt="">Mayotte</option>
                        <option value="MX" data-alt="">Mexico</option>
                        <option value="MC" data-alt="">Monaco</option>
                        <option value="MN" data-alt="">Mongolia</option>
                        <option value="MS" data-alt="">Montserrat</option>
                        <option value="MA" data-alt="">Morocco</option>
                        <option value="MZ" data-alt="">Mozambique</option>
                        <option value="MM" data-alt="">Myanmar</option>
                        <option value="NA" data-alt="">Namibia</option>
                        <option value="NR" data-alt="">Nauru</option>
                        <option value="NP" data-alt="">Nepal</option>
                        <option value="NL" data-alt="">Netherlands</option>
                        <option value="AN" data-alt="">Netherlands Antilles</option>
                        <option value="NC" data-alt="">New Caledonia</option>
                        <option value="NZ" data-alt="">New Zealand</option>
                        <option value="NI" data-alt="">Nicaragua</option>
                        <option value="NE" data-alt="">Niger</option>
                        <option value="NG" data-alt="">Nigeria</option>
                        <option value="NU" data-alt="">Niue</option>
                        <option value="NO" data-alt="">Norway</option>
                        <option value="OM" data-alt="">Oman</option>
                        <option value="PK" data-alt="">Pakistan</option>
                        <option value="PW" data-alt="">Palau</option>
                        <option value="PA" data-alt="">Panama</option>
                        <option value="PG" data-alt="">Papua New Guinea</option>
                        <option value="PY" data-alt="">Paraguay</option>
                        <option value="PH" data-alt="">Philippines</option>
                        <option value="PL" data-alt="">Poland</option>
                        <option value="PT" data-alt="">Portugal</option>
                        <option value="PR" data-alt="">Puerto Rico</option>
                        <option value="QA" data-alt="">Qatar</option>
                        <option value="RE" data-alt="">Reunion</option>
                        <option value="RO" data-alt="">Romania</option>
                        <option value="RW" data-alt="">Rwanda</option>
                        <option value="LC" data-alt="">Saint Lucia</option>
                        <option value="WS" data-alt="">Samoa</option>
                        <option value="ST" data-alt="">Sao Tome and Principe</option>
                        <option value="SA" data-alt="">Saudi Arabia</option>
                        <option value="SN" data-alt="">Senegal</option>
                        <option value="SC" data-alt="">Seychelles</option>
                        <option value="SL" data-alt="">Sierra Leone</option>
                        <option value="SG" data-alt="">Singapore</option>
                        <option value="SK" data-alt="">Slovakia</option>
                        <option value="SI" data-alt="">Slovenia</option>
                        <option value="SB" data-alt="">Solomon Islands</option>
                        <option value="SO" data-alt="">Somalia</option>
                        <option value="ZA" data-alt="">South Africa</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="SD" data-alt="">Sudan</option>
                        <option value="SR" data-alt="">Suriname</option>
                        <option value="SZ" data-alt="">Swaziland</option>
                        <option value="SE" data-alt="">Sweden</option>
                        <option value="CH" data-alt="">Switzerland</option>
                        <option value="SY" data-alt="">Syrian Arab Republic</option>
                        <option value="TW" data-alt="">Taiwan, Province of China</option>
                        <option value="TJ" data-alt="">Tajikistan</option>
                        <option value="TZ" data-alt="">Tanzania, United Republic of</option>
                        <option value="TH" data-alt="">Thailand</option>
                        <option value="TG" data-alt="">Togo</option>
                        <option value="TO" data-alt="">Tonga</option>
                        <option value="TT" data-alt="">Trinidad and Tobago</option>
                        <option value="TN" data-alt="">Tunisia</option>
                        <option value="TC" data-alt="">Turks and Caicos Islands</option>
                        <option value="TV" data-alt="">Tuvalu</option>
                        <option value="UG" data-alt="">Uganda</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="AE" data-alt="uae">United Arab Emirates</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="UY" data-alt="">Uruguay</option>
                        <option value="UZ" data-alt="">Uzbekistan</option>
                        <option value="VU" data-alt="">Vanuatu</option>
                        <option value="VE" data-alt="">Venezuela</option>
                        <option value="VN" data-alt="">Viet Nam</option>
                        <option value="VG" data-alt="">Virgin Islands, British</option>
                        <option value="ZM" data-alt="">Zambia</option>
                        <option value="ZW" data-alt="">Zimbabwe</option>
                    </optgroup>
                </select>
            <button type="submit" id="btn-quick-quote" class="col-md-1 btn btn-primary">Go</button>
        </form>
    </div>

	<div class="entry-content">
    	<div class="container">
            <div class="row">
            	<div class="col-7">
                    <h3 class="text-uppercase">How It Works</h3>
                </div>
                <div class="col">
                    <div class="text-uppercase text-right"><a href="">Find Out More &gt;&gt;</a></div>
                </div>
            </div>
            <div id="hiw" class="row mt-4">
                <div class="col-md-2">
                	<a href="">
                        <div id="hiw1" class="hiw-icon"></div>
                        <div class="hiw-label mt-4 text-uppercase text-center">Get a Quote</div>
                    </a>
                </div>
                <div class="col-md-2">
                	<a href="">
                        <div id="hiw2" class="hiw-icon"></div>
                        <div class="hiw-label mt-4 text-uppercase text-center">Book Online</div>
                    </a>
                </div>
                <div class="col-md-2">
                	<a href="">
                        <div id="hiw3" class="hiw-icon"></div>
                        <div class="hiw-label mt-4 text-uppercase text-center">Prepare Your Stuff</div>
                    </a>
                </div>
                <div class="col-md-2">
                	<a href="">
                        <div id="hiw4" class="hiw-icon"></div>
                        <div class="hiw-label mt-4 text-uppercase text-center">Collection</div>
                    </a>
                </div>
                <div class="col-md-2">
                	<a href="">
                        <div id="hiw5" class="hiw-icon"></div>
                        <div class="hiw-label mt-4 text-uppercase text-center">Track Your Stuff</div>
                    </a>
                </div>
                <div class="col-md-2">
                	<a href="">
                        <div id="hiw6" class="hiw-icon"></div>
                        <div class="hiw-label mt-4 text-uppercase text-center">Delivery</div>
                    </a>
                </div>
            </div>
            <div class="row mt-4">
            	<div class="col-md-6 orangetextbox">
                    <h3 class="text-uppercase">Our Guarantee</h3>
                    <br/>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> Worldwide Door to Door Luggage Delivery Service</p>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> Send up to 30kg & Sports Equipment</p>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> Global Courier Network | Safe & Secure</p>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> Cheaper than Airline Excess Baggage Charges</p>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> No waiting for luggage at the airport carousel</p>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> Hands-Free Travel | Save Time, Stress & Money</p>
                    <p><i style="font-size:2rem;" class="fa fa-check-square-o" aria-hidden="true"></i> We specialise in On-Time Delivery</p>
                    <a href="">Read more about our pricing >></a>
                </div>
                <div class="col-md-6" style="padding-right:0;">
                    <a href="https://uk.trustpilot.com/review/www.dhl.co.uk">
                        <img class="img-fluid" src="/wp-content/themes/EMSTheme/images/reviews.jpg" />
                    </a>
                </div>
            </div>
            <div class="row mt-4 hppricebox">
            	<div class="col-md-9">
                    <h3 class="text-uppercase">International Luggage Shipping Services</h3>
                </div>
                <div class="col-md-3">
                    <div class="text-uppercase text-right"><a href="">Find Out More &gt;&gt;</a></div>
                </div>
                <div class="col-md-2 shipping-destination mt-2">
                	<a href="/quote?from=GB&amp;to=GB">
                        UK
                        <div class="shipping-price">£15</div>
                    </a>
                </div>
                <div class="col-md-2 shipping-destination mt-2">
                    <a href="/quote?from=GB&amp;to=ES">
                        Spain
                        <div class="shipping-price">£31</div>
                    </a>
                </div>
                <div class="col-md-2 shipping-destination mt-2">
                    <a href="/quote?from=GB&amp;to=US">
                        United States
                        <div class="shipping-price">£35</div>
                    </a>
                </div>
                <div class="col-md-2 shipping-destination mt-2">
                    <a href="/quote?from=GB&amp;to=AU">
                        Australia
                        <div class="shipping-price">£48</div>
                    </a>
                </div>
                <div class="col-md-2 shipping-destination mt-2">
                    <a href="/quote?from=GB&amp;to=FR">
                        France
                        <div class="shipping-price">£29</div>
                    </a>
                </div>
                <div class="col-md-2 shipping-destination mt-2">
                    <a href="/quote?from=GB&amp;to=DE">
                    	Germany
                    	<div class="shipping-price">£29</div>
                    </a>
                </div>
            </div>
            <div class="row mt-4">
            	<div class="col-md-6">
                	<div class="hp-widget hp-student bgfadein">
                        <div class="textposition">
                            <div class="whitetextboxlp">
                                <h2 class="text-right"><strong>Shipping For Students</strong></h2>
                                <div class="text-right">Student discount available with #EMSStudents, NUS &amp; UCAS.</div>
                            </div>
                            <a class="float-right whitetextboxlp" href="Read More">Read More >></a>
                        </div>
                    </div>
                </div>
            	<div class="col-md-6">
                	<div class="hp-widget hp-business bgfadein">
                        <div class="textposition">
                            <div class="whitetextboxlp">
                                <h2><strong>Worldwide Destinations</strong></h2>
                                <div>International baggage shipping for business people &amp; holiday makers.</div>
                            </div>
                            <a class="whitetextboxlp" href="Read More">Read More >></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
            	<?php the_content(); ?>
            </div>
        </div>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
    
	</footer><!-- .entry-footer -->

</article><!-- #post-## -->