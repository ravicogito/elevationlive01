<?php
/**
 * Partial template for content in quotepage.php
 *
 * @package understrap
 */

?>
<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">

	<header class="entry-header whitetextbox">
		<?php the_title( '<h1 class="entry-title orangetext">', '</h1>' );
		$subtitle = get_post_meta($post->ID, 'Subtitle', $single = true);
		if($subtitle !== '') echo '<h2>' . $subtitle . '</h2>'; ?>
	</header><!-- .entry-header -->
    
    <div class="quick-quote-container">
    	<form action="/quote" class="form-inline" id="quick-quote" method="post" novalidate="novalidate">
            <input name="__RequestVerificationToken" type="hidden" >
            <div class="col-md-6">
                <label for="Origin_CountryIso">Collection Country</label>
                <select id="Origin_CountryIso" name="Origin.CountryIso" style="width:100%" class="custom-select" placeholder="select a country" autocomplete="false" data-bind="value: CountryIso" data-val="true" data-val-required="Country is required." tabindex="-1" title="Send From">
                    <optgroup label="Most Popular">
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain" selected>UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="IE" data-alt="">Ireland</option>
                    </optgroup>
                    <optgroup label="A-Z">
                        <option value="AF" data-alt="">Afghanistan</option>
                        <option value="AL" data-alt="">Albania</option>
                        <option value="DZ" data-alt="">Algeria</option>
                        <option value="AS" data-alt="">American Samoa</option>
                        <option value="AD" data-alt="">Andorra</option>
                        <option value="AO" data-alt="">Angola</option>
                        <option value="AI" data-alt="">Anguilla</option>
                        <option value="AG" data-alt="">Antigua and Barbuda</option>
                        <option value="AM" data-alt="">Armenia</option>
                        <option value="AW" data-alt="">Aruba</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="AT" data-alt="">Austria</option>
                        <option value="AZ" data-alt="">Azerbaijan</option>
                        <option value="BS" data-alt="">Bahamas</option>
                        <option value="BH" data-alt="">Bahrain</option>
                        <option value="BD" data-alt="">Bangladesh</option>
                        <option value="BB" data-alt="">Barbados</option>
                        <option value="BY" data-alt="">Belarus</option>
                        <option value="BE" data-alt="">Belgium</option>
                        <option value="BZ" data-alt="">Belize</option>
                        <option value="BJ" data-alt="">Benin</option>
                        <option value="BM" data-alt="">Bermuda</option>
                        <option value="BT" data-alt="">Bhutan</option>
                        <option value="BO" data-alt="">Bolivia</option>
                        <option value="BA" data-alt="">Bosnia and Herzegovina</option>
                        <option value="BW" data-alt="">Botswana</option>
                        <option value="BR" data-alt="">Brazil</option>
                        <option value="BN" data-alt="">Brunei Darussalam</option>
                        <option value="BG" data-alt="">Bulgaria</option>
                        <option value="BF" data-alt="">Burkina Faso</option>
                        <option value="BI" data-alt="">Burundi</option>
                        <option value="KH" data-alt="">Cambodia</option>
                        <option value="CM" data-alt="">Cameroon</option>
                        <option value="CA" data-alt="">Canada</option>
                        <option value="CV" data-alt="">Cape Verde</option>
                        <option value="KY" data-alt="">Cayman Islands</option>
                        <option value="CF" data-alt="">Central African Republic</option>
                        <option value="TD" data-alt="">Chad</option>
                        <option value="CL" data-alt="">Chile</option>
                        <option value="CN" data-alt="">China</option>
                        <option value="CO" data-alt="">Colombia</option>
                        <option value="KM" data-alt="">Comoros</option>
                        <option value="CG" data-alt="">Congo</option>
                        <option value="CK" data-alt="">Cook Islands</option>
                        <option value="CR" data-alt="">Costa Rica</option>
                        <option value="CI" data-alt="">Cote D'Ivoire</option>
                        <option value="HR" data-alt="">Croatia</option>
                        <option value="CU" data-alt="">Cuba</option>
                        <option value="CY" data-alt="">Cyprus</option>
                        <option value="CZ" data-alt="">Czech Republic</option>
                        <option value="DK" data-alt="">Denmark</option>
                        <option value="DJ" data-alt="">Djibouti</option>
                        <option value="DM" data-alt="">Dominica</option>
                        <option value="DO" data-alt="">Dominican Republic</option>
                        <option value="EC" data-alt="">Ecuador</option>
                        <option value="EG" data-alt="">Egypt</option>
                        <option value="SV" data-alt="">El Salvador</option>
                        <option value="GQ" data-alt="">Equatorial Guinea</option>
                        <option value="ER" data-alt="">Eritrea</option>
                        <option value="EE" data-alt="">Estonia</option>
                        <option value="ET" data-alt="">Ethiopia</option>
                        <option value="FK" data-alt="">Falkland Islands (Malvinas)</option>
                        <option value="FJ" data-alt="">Fiji</option>
                        <option value="FI" data-alt="">Finland</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="GF" data-alt="">French Guiana</option>
                        <option value="GA" data-alt="">Gabon</option>
                        <option value="GM" data-alt="">Gambia</option>
                        <option value="GE" data-alt="">Georgia</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="GH" data-alt="">Ghana</option>
                        <option value="GI" data-alt="">Gibraltar</option>
                        <option value="GR" data-alt="">Greece</option>
                        <option value="GD" data-alt="">Grenada</option>
                        <option value="GP" data-alt="">Guadeloupe</option>
                        <option value="GU" data-alt="">Guam</option>
                        <option value="GT" data-alt="">Guatemala</option>
                        <option value="GG" data-alt="UK United Kingdom England Great Britain Channel Islands">Guernsey</option>
                        <option value="GN" data-alt="">Guinea</option>
                        <option value="GW" data-alt="">Guinea-Bissau</option>
                        <option value="HT" data-alt="">Haiti</option>
                        <option value="HN" data-alt="">Honduras</option>
                        <option value="HK" data-alt="">Hong Kong</option>
                        <option value="HU" data-alt="">Hungary</option>
                        <option value="IS" data-alt="">Iceland</option>
                        <option value="IN" data-alt="">India</option>
                        <option value="ID" data-alt="">Indonesia</option>
                        <option value="IR" data-alt="">Iran, Islamic Republic of</option>
                        <option value="IQ" data-alt="">Iraq</option>
                        <option value="IE" data-alt="">Ireland</option>
                        <option value="IL" data-alt="">Israel</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="JM" data-alt="">Jamaica</option>
                        <option value="JP" data-alt="">Japan</option>
                        <option value="JE" data-alt="UK United Kingdom England Great Britain Channel Islands">Jersey</option>
                        <option value="JO" data-alt="">Jordan</option>
                        <option value="KZ" data-alt="">Kazakhstan</option>
                        <option value="KE" data-alt="">Kenya</option>
                        <option value="KP" data-alt="">Korea, Democratic People's Republic of</option>
                        <option value="KR" data-alt="South Korea">Korea, Republic of</option>
                        <option value="KW" data-alt="">Kuwait</option>
                        <option value="KG" data-alt="">Kyrgyzstan</option>
                        <option value="LA" data-alt="">Lao People's Democratic Republic</option>
                        <option value="LV" data-alt="">Latvia</option>
                        <option value="LB" data-alt="">Lebanon</option>
                        <option value="LS" data-alt="">Lesotho</option>
                        <option value="LR" data-alt="">Liberia</option>
                        <option value="LY" data-alt="">Libyan Arab Jamahiriya</option>
                        <option value="LI" data-alt="">Liechtenstein</option>
                        <option value="LT" data-alt="">Lithuania</option>
                        <option value="LU" data-alt="">Luxembourg</option>
                        <option value="MO" data-alt="">Macao</option>
                        <option value="MK" data-alt="">Macedonia, the Former Yugoslav Republic of</option>
                        <option value="MG" data-alt="">Madagascar</option>
                        <option value="MW" data-alt="">Malawi</option>
                        <option value="MY" data-alt="">Malaysia</option>
                        <option value="MV" data-alt="">Maldives</option>
                        <option value="ML" data-alt="">Mali</option>
                        <option value="MT" data-alt="">Malta</option>
                        <option value="MH" data-alt="">Marshall Islands</option>
                        <option value="MQ" data-alt="">Martinique</option>
                        <option value="MR" data-alt="">Mauritania</option>
                        <option value="MU" data-alt="">Mauritius</option>
                        <option value="YT" data-alt="">Mayotte</option>
                        <option value="MX" data-alt="">Mexico</option>
                        <option value="MD" data-alt="">Moldova, Republic of</option>
                        <option value="MC" data-alt="">Monaco</option>
                        <option value="MN" data-alt="">Mongolia</option>
                        <option value="MS" data-alt="">Montserrat</option>
                        <option value="MA" data-alt="">Morocco</option>
                        <option value="MZ" data-alt="">Mozambique</option>
                        <option value="MM" data-alt="">Myanmar</option>
                        <option value="NA" data-alt="">Namibia</option>
                        <option value="NR" data-alt="">Nauru</option>
                        <option value="NP" data-alt="">Nepal</option>
                        <option value="NL" data-alt="">Netherlands</option>
                        <option value="AN" data-alt="">Netherlands Antilles</option>
                        <option value="NC" data-alt="">New Caledonia</option>
                        <option value="NZ" data-alt="">New Zealand</option>
                        <option value="NI" data-alt="">Nicaragua</option>
                        <option value="NE" data-alt="">Niger</option>
                        <option value="NG" data-alt="">Nigeria</option>
                        <option value="NU" data-alt="">Niue</option>
                        <option value="NO" data-alt="">Norway</option>
                        <option value="OM" data-alt="">Oman</option>
                        <option value="PK" data-alt="">Pakistan</option>
                        <option value="PW" data-alt="">Palau</option>
                        <option value="PA" data-alt="">Panama</option>
                        <option value="PG" data-alt="">Papua New Guinea</option>
                        <option value="PY" data-alt="">Paraguay</option>
                        <option value="PE" data-alt="">Peru</option>
                        <option value="PH" data-alt="">Philippines</option>
                        <option value="PL" data-alt="">Poland</option>
                        <option value="PT" data-alt="">Portugal</option>
                        <option value="PR" data-alt="">Puerto Rico</option>
                        <option value="QA" data-alt="">Qatar</option>
                        <option value="RE" data-alt="">Reunion</option>
                        <option value="RO" data-alt="">Romania</option>
                        <option value="RW" data-alt="">Rwanda</option>
                        <option value="KN" data-alt="">Saint Kitts and Nevis</option>
                        <option value="VC" data-alt="">Saint Vincent and the Grenadines</option>
                        <option value="WS" data-alt="">Samoa</option>
                        <option value="ST" data-alt="">Sao Tome and Principe</option>
                        <option value="SA" data-alt="">Saudi Arabia</option>
                        <option value="SN" data-alt="">Senegal</option>
                        <option value="SC" data-alt="">Seychelles</option>
                        <option value="SL" data-alt="">Sierra Leone</option>
                        <option value="SG" data-alt="">Singapore</option>
                        <option value="SK" data-alt="">Slovakia</option>
                        <option value="SI" data-alt="">Slovenia</option>
                        <option value="SB" data-alt="">Solomon Islands</option>
                        <option value="SO" data-alt="">Somalia</option>
                        <option value="ZA" data-alt="">South Africa</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="LK" data-alt="">Sri Lanka</option>
                        <option value="SD" data-alt="">Sudan</option>
                        <option value="SR" data-alt="">Suriname</option>
                        <option value="SZ" data-alt="">Swaziland</option>
                        <option value="SE" data-alt="">Sweden</option>
                        <option value="CH" data-alt="">Switzerland</option>
                        <option value="SY" data-alt="">Syrian Arab Republic</option>
                        <option value="TW" data-alt="">Taiwan, Province of China</option>
                        <option value="TJ" data-alt="">Tajikistan</option>
                        <option value="TZ" data-alt="">Tanzania, United Republic of</option>
                        <option value="TH" data-alt="">Thailand</option>
                        <option value="TG" data-alt="">Togo</option>
                        <option value="TO" data-alt="">Tonga</option>
                        <option value="TT" data-alt="">Trinidad and Tobago</option>
                        <option value="TC" data-alt="">Turks and Caicos Islands</option>
                        <option value="TV" data-alt="">Tuvalu</option>
                        <option value="UG" data-alt="">Uganda</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain" selected="selected">UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="UA" data-alt="">Ukraine</option>
                        <option value="AE" data-alt="uae">United Arab Emirates</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="UY" data-alt="">Uruguay</option>
                        <option value="UZ" data-alt="">Uzbekistan</option>
                        <option value="VU" data-alt="">Vanuatu</option>
                        <option value="VE" data-alt="">Venezuela</option>
                        <option value="VN" data-alt="">Viet Nam</option>
                        <option value="VG" data-alt="">Virgin Islands, British</option>
                        <option value="VI" data-alt="">Virgin Islands, U.s.</option>
                        <option value="YE" data-alt="">Yemen</option>
                        <option value="ZM" data-alt="">Zambia</option>
                        <option value="ZW" data-alt="">Zimbabwe</option>
                    </optgroup>
                </select>
            </div>
            <div class="mt-3 mt-md-0 col-md-6">
                <label for="Destination_CountryIso">Destination Country</label>
                <select id="Destination_CountryIso" name="Destination.CountryIso" style="width:100%" class="custom-select" placeholder="select a country" autocomplete="false" data-bind="value: CountryIso" data-val="true" data-val-required="Country is required." tabindex="-1" title="To">
                	<option value="">select a country</option>
                    <optgroup label="Most Popular">
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="IE" data-alt="">Ireland</option>
                    </optgroup>
                    <optgroup label="A-Z">
                        <option value="AF" data-alt="">Afghanistan</option>
                        <option value="DZ" data-alt="">Algeria</option>
                        <option value="AS" data-alt="">American Samoa</option>
                        <option value="AO" data-alt="">Angola</option>
                        <option value="AI" data-alt="">Anguilla</option>
                        <option value="AM" data-alt="">Armenia</option>
                        <option value="AW" data-alt="">Aruba</option>
                        <option value="AU" data-alt="">Australia</option>
                        <option value="AT" data-alt="">Austria</option>
                        <option value="AZ" data-alt="">Azerbaijan</option>
                        <option value="BS" data-alt="">Bahamas</option>
                        <option value="BH" data-alt="">Bahrain</option>
                        <option value="BD" data-alt="">Bangladesh</option>
                        <option value="BB" data-alt="">Barbados</option>
                        <option value="BE" data-alt="">Belgium</option>
                        <option value="BZ" data-alt="">Belize</option>
                        <option value="BJ" data-alt="">Benin</option>
                        <option value="BM" data-alt="">Bermuda</option>
                        <option value="BT" data-alt="">Bhutan</option>
                        <option value="BO" data-alt="">Bolivia</option>
                        <option value="BW" data-alt="">Botswana</option>
                        <option value="BR" data-alt="">Brazil</option>
                        <option value="BN" data-alt="">Brunei Darussalam</option>
                        <option value="BG" data-alt="">Bulgaria</option>
                        <option value="BF" data-alt="">Burkina Faso</option>
                        <option value="BI" data-alt="">Burundi</option>
                        <option value="KH" data-alt="">Cambodia</option>
                        <option value="CM" data-alt="">Cameroon</option>
                        <option value="CA" data-alt="">Canada</option>
                        <option value="CV" data-alt="">Cape Verde</option>
                        <option value="CF" data-alt="">Central African Republic</option>
                        <option value="TD" data-alt="">Chad</option>
                        <option value="CL" data-alt="">Chile</option>
                        <option value="CO" data-alt="">Colombia</option>
                        <option value="CG" data-alt="">Congo</option>
                        <option value="CK" data-alt="">Cook Islands</option>
                        <option value="CR" data-alt="">Costa Rica</option>
                        <option value="CI" data-alt="">Cote D'Ivoire</option>
                        <option value="HR" data-alt="">Croatia</option>
                        <option value="CU" data-alt="">Cuba</option>
                        <option value="CY" data-alt="">Cyprus</option>
                        <option value="CZ" data-alt="">Czech Republic</option>
                        <option value="DK" data-alt="">Denmark</option>
                        <option value="DJ" data-alt="">Djibouti</option>
                        <option value="DM" data-alt="">Dominica</option>
                        <option value="DO" data-alt="">Dominican Republic</option>
                        <option value="EC" data-alt="">Ecuador</option>
                        <option value="EG" data-alt="">Egypt</option>
                        <option value="SV" data-alt="">El Salvador</option>
                        <option value="GQ" data-alt="">Equatorial Guinea</option>
                        <option value="ER" data-alt="">Eritrea</option>
                        <option value="EE" data-alt="">Estonia</option>
                        <option value="ET" data-alt="">Ethiopia</option>
                        <option value="FK" data-alt="">Falkland Islands (Malvinas)</option>
                        <option value="FJ" data-alt="">Fiji</option>
                        <option value="FI" data-alt="">Finland</option>
                        <option value="FR" data-alt="">France</option>
                        <option value="GF" data-alt="">French Guiana</option>
                        <option value="GA" data-alt="">Gabon</option>
                        <option value="GM" data-alt="">Gambia</option>
                        <option value="GE" data-alt="">Georgia</option>
                        <option value="DE" data-alt="">Germany</option>
                        <option value="GH" data-alt="">Ghana</option>
                        <option value="GR" data-alt="">Greece</option>
                        <option value="GD" data-alt="">Grenada</option>
                        <option value="GP" data-alt="">Guadeloupe</option>
                        <option value="GU" data-alt="">Guam</option>
                        <option value="GT" data-alt="">Guatemala</option>
                        <option value="GG" data-alt="UK United Kingdom England Great Britain Channel Islands">Guernsey</option>
                        <option value="GW" data-alt="">Guinea-Bissau</option>
                        <option value="GY" data-alt="">Guyana</option>
                        <option value="HT" data-alt="">Haiti</option>
                        <option value="HN" data-alt="">Honduras</option>
                        <option value="HK" data-alt="">Hong Kong</option>
                        <option value="HU" data-alt="">Hungary</option>
                        <option value="IS" data-alt="">Iceland</option>
                        <option value="IN" data-alt="">India</option>
                        <option value="ID" data-alt="">Indonesia</option>
                        <option value="IR" data-alt="">Iran, Islamic Republic of</option>
                        <option value="IQ" data-alt="">Iraq</option>
                        <option value="IE" data-alt="">Ireland</option>
                        <option value="IL" data-alt="">Israel</option>
                        <option value="IT" data-alt="">Italy</option>
                        <option value="JM" data-alt="">Jamaica</option>
                        <option value="JP" data-alt="">Japan</option>
                        <option value="JE" data-alt="UK United Kingdom England Great Britain Channel Islands">Jersey</option>
                        <option value="JO" data-alt="">Jordan</option>
                        <option value="KZ" data-alt="">Kazakhstan</option>
                        <option value="KE" data-alt="">Kenya</option>
                        <option value="KI" data-alt="">Kiribati</option>
                        <option value="KR" data-alt="South Korea">Korea, Republic of</option>
                        <option value="KW" data-alt="">Kuwait</option>
                        <option value="KG" data-alt="">Kyrgyzstan</option>
                        <option value="LV" data-alt="">Latvia</option>
                        <option value="LB" data-alt="">Lebanon</option>
                        <option value="LS" data-alt="">Lesotho</option>
                        <option value="LR" data-alt="">Liberia</option>
                        <option value="LT" data-alt="">Lithuania</option>
                        <option value="LU" data-alt="">Luxembourg</option>
                        <option value="MO" data-alt="">Macao</option>
                        <option value="MG" data-alt="">Madagascar</option>
                        <option value="MW" data-alt="">Malawi</option>
                        <option value="MY" data-alt="">Malaysia</option>
                        <option value="MV" data-alt="">Maldives</option>
                        <option value="MT" data-alt="">Malta</option>
                        <option value="MH" data-alt="">Marshall Islands</option>
                        <option value="MQ" data-alt="">Martinique</option>
                        <option value="MR" data-alt="">Mauritania</option>
                        <option value="MU" data-alt="">Mauritius</option>
                        <option value="YT" data-alt="">Mayotte</option>
                        <option value="MX" data-alt="">Mexico</option>
                        <option value="MC" data-alt="">Monaco</option>
                        <option value="MN" data-alt="">Mongolia</option>
                        <option value="MS" data-alt="">Montserrat</option>
                        <option value="MA" data-alt="">Morocco</option>
                        <option value="MZ" data-alt="">Mozambique</option>
                        <option value="MM" data-alt="">Myanmar</option>
                        <option value="NA" data-alt="">Namibia</option>
                        <option value="NR" data-alt="">Nauru</option>
                        <option value="NP" data-alt="">Nepal</option>
                        <option value="NL" data-alt="">Netherlands</option>
                        <option value="AN" data-alt="">Netherlands Antilles</option>
                        <option value="NC" data-alt="">New Caledonia</option>
                        <option value="NZ" data-alt="">New Zealand</option>
                        <option value="NI" data-alt="">Nicaragua</option>
                        <option value="NE" data-alt="">Niger</option>
                        <option value="NG" data-alt="">Nigeria</option>
                        <option value="NU" data-alt="">Niue</option>
                        <option value="NO" data-alt="">Norway</option>
                        <option value="OM" data-alt="">Oman</option>
                        <option value="PK" data-alt="">Pakistan</option>
                        <option value="PW" data-alt="">Palau</option>
                        <option value="PA" data-alt="">Panama</option>
                        <option value="PG" data-alt="">Papua New Guinea</option>
                        <option value="PY" data-alt="">Paraguay</option>
                        <option value="PH" data-alt="">Philippines</option>
                        <option value="PL" data-alt="">Poland</option>
                        <option value="PT" data-alt="">Portugal</option>
                        <option value="PR" data-alt="">Puerto Rico</option>
                        <option value="QA" data-alt="">Qatar</option>
                        <option value="RE" data-alt="">Reunion</option>
                        <option value="RO" data-alt="">Romania</option>
                        <option value="RW" data-alt="">Rwanda</option>
                        <option value="LC" data-alt="">Saint Lucia</option>
                        <option value="WS" data-alt="">Samoa</option>
                        <option value="ST" data-alt="">Sao Tome and Principe</option>
                        <option value="SA" data-alt="">Saudi Arabia</option>
                        <option value="SN" data-alt="">Senegal</option>
                        <option value="SC" data-alt="">Seychelles</option>
                        <option value="SL" data-alt="">Sierra Leone</option>
                        <option value="SG" data-alt="">Singapore</option>
                        <option value="SK" data-alt="">Slovakia</option>
                        <option value="SI" data-alt="">Slovenia</option>
                        <option value="SB" data-alt="">Solomon Islands</option>
                        <option value="SO" data-alt="">Somalia</option>
                        <option value="ZA" data-alt="">South Africa</option>
                        <option value="ES" data-alt="">Spain</option>
                        <option value="SD" data-alt="">Sudan</option>
                        <option value="SR" data-alt="">Suriname</option>
                        <option value="SZ" data-alt="">Swaziland</option>
                        <option value="SE" data-alt="">Sweden</option>
                        <option value="CH" data-alt="">Switzerland</option>
                        <option value="SY" data-alt="">Syrian Arab Republic</option>
                        <option value="TW" data-alt="">Taiwan, Province of China</option>
                        <option value="TJ" data-alt="">Tajikistan</option>
                        <option value="TZ" data-alt="">Tanzania, United Republic of</option>
                        <option value="TH" data-alt="">Thailand</option>
                        <option value="TG" data-alt="">Togo</option>
                        <option value="TO" data-alt="">Tonga</option>
                        <option value="TT" data-alt="">Trinidad and Tobago</option>
                        <option value="TN" data-alt="">Tunisia</option>
                        <option value="TC" data-alt="">Turks and Caicos Islands</option>
                        <option value="TV" data-alt="">Tuvalu</option>
                        <option value="UG" data-alt="">Uganda</option>
                        <option value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</option>
                        <option value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Mainland</option>
                        <option value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</option>
                        <option value="AE" data-alt="uae">United Arab Emirates</option>
                        <option value="US" data-alt="US USA America">United States</option>
                        <option value="UY" data-alt="">Uruguay</option>
                        <option value="UZ" data-alt="">Uzbekistan</option>
                        <option value="VU" data-alt="">Vanuatu</option>
                        <option value="VE" data-alt="">Venezuela</option>
                        <option value="VN" data-alt="">Viet Nam</option>
                        <option value="VG" data-alt="">Virgin Islands, British</option>
                        <option value="ZM" data-alt="">Zambia</option>
                        <option value="ZW" data-alt="">Zimbabwe</option>
                    </optgroup>
                </select>
            </div>
            <div class="mt-3 col-md-6">
                <label for="Collection_Postcode">Collection Postcode <small class="text-muted">(If Available)</small></label>
                <input style="width:100%;" type="text" class="form-control" id="Collection_Postcode">
            </div>
            <div class="mt-3 col-md-6">
                <label for="Destination_Postcode">Destination Postcode <small class="text-muted">(If Available)</small></label>
                <input style="width:100%;" type="text" class="form-control" id="Destination_Postcode">
            </div>
            <div class="mt-3 col-md-12">
                <p class="orangetext">Please enter postcodes for a more accurate delivery time and price. Without postcodes the quote assumes capital to capital.</p>
            </div>
        </form>
            <div class="col-md-12">
            	<h4>Your Journey</h4>
                <div class="form-check form-check-inline">
                    <label class="custom-control custom-radio">
                        <input class="custom-control-input" type="radio" name="radioJourney" id="OneWayJourney" value="OneWayJourney" checked>
                        <span class="custom-control-indicator"></span>
                        <span class="custom-control-description">One Way</span>
                    </label>
                </div>
                <div class="form-check form-check-inline">
                    <label class="custom-control custom-radio">
                        <input class="custom-control-input" type="radio" name="radioJourney" id="ReturnJourney" value="ReturnJourney">
                        <span class="custom-control-indicator"></span>
                        <span class="custom-control-description">Return Journey</span>
                    </label>
                </div>
                <div class="row mt-3 no-gutters greybgheader">
                    <div class="col-4">
                        Service
                    </div>
                    <div class="col-8">
                        Price (Per Item)
                    </div>
                </div>
                <div class="row no-gutters whitetextboxlp" style="border: solid 1px #333; border-top: 0;">	
                    <div class="col-md-4">
                        <div class="orangetext">Standard</div>
                        2-3 working days
                    </div>
                    <div class="col-md-5">
                    	<div><span class="quick-quote-price-weight">up to <!--ko text: Math.floor(MaxWeight())-->20<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(PriceIncTax())" class="quick-quote-price">£29.00</span></div>
                        <div><span class="quick-quote-price-weight">up to <!--ko text: Math.floor(MaxWeight())-->30<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(PriceIncTax())" class="quick-quote-price">£30.00</span></div>
                        <div data-bind="visible:$parent.MaxWeight() > MaxTierWeight()"><span class="quick-quote-price-weight">over <!--ko text: Math.floor(MaxTierWeight())-->30<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(MaxTierPriceIncTax())" class="quick-quote-price">£30.00</span> + <span data-bind="text: Localise.formatCurrency(PricePerKgOverWeightIncTax())" class="quick-quote-price">£2.00</span> per additional kg</div>
                    </div>
                    <div class="col-md-3">
                    	<form action="/order" method="post"><input name="__RequestVerificationToken" type="hidden">                            
                        	<input type="hidden" name="Origin.CountryIso" data-bind="value:$parent.Origin.CountryIso" value="DE">
                            <input type="hidden" name="Origin.Postcode" data-bind="value:$parent.Origin.Postcode" value="">
                            <input type="hidden" name="Origin.RegionId" data-bind="value:$parent.Origin.RegionId">
                            <input type="hidden" name="Destination.CountryIso" data-bind="value:$parent.Destination.CountryIso" value="GB">
                            <input type="hidden" name="Destination.Postcode" data-bind="value:$parent.Destination.Postcode" value="">
                            <input type="hidden" name="Destination.RegionId" data-bind="value:$parent.Destination.RegionId">
                            <input type="hidden" name="JourneyType" data-bind="value:$parent.JourneyType" value="OneWay">
                            <input type="hidden" name="TotalBags" data-bind="value:$parent.TotalBags" value="1">
                            <input type="hidden" name="DeliveryMethodType" data-bind="value:DeliveryMethodType" value="1">
                            <button type="submit" class="btn btn-primary btn-lg">Book Now</button>
                        </form>
                    </div>
                </div>
                <div class="row no-gutters whitetextboxlp" style="border: solid 1px #333; border-top: 0;">	
                    <div class="col-md-4">
                        <div class="orangetext">Express</div>
                        1-2 working days
                    </div>
                    <div class="col-md-5">
                    	<div><span class="quick-quote-price-weight">up to <!--ko text: Math.floor(MaxWeight())-->5<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(PriceIncTax())" class="quick-quote-price">£38.00</span></div>
                        <div><span class="quick-quote-price-weight">up to <!--ko text: Math.floor(MaxWeight())-->20<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(PriceIncTax())" class="quick-quote-price">£79.00</span></div>
                        <div><span class="quick-quote-price-weight">up to <!--ko text: Math.floor(MaxWeight())-->30<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(PriceIncTax())" class="quick-quote-price">£99.00</span></div>
                        <div data-bind="visible:$parent.MaxWeight() > MaxTierWeight()"><span class="quick-quote-price-weight">over <!--ko text: Math.floor(MaxTierWeight())-->30<!--/ko-->kg:</span> <span data-bind="text: Localise.formatCurrency(MaxTierPriceIncTax())" class="quick-quote-price">£99.00</span> + <span data-bind="text: Localise.formatCurrency(PricePerKgOverWeightIncTax())" class="quick-quote-price">£3.20</span> per additional kg</div>
                    </div>
                    <div class="col-md-3">
                    	<form action="/order" method="post"><input name="__RequestVerificationToken" type="hidden">                            
                        	<input type="hidden" name="Origin.CountryIso" data-bind="value:$parent.Origin.CountryIso" value="DE">
                            <input type="hidden" name="Origin.Postcode" data-bind="value:$parent.Origin.Postcode" value="">
                            <input type="hidden" name="Origin.RegionId" data-bind="value:$parent.Origin.RegionId">
                            <input type="hidden" name="Destination.CountryIso" data-bind="value:$parent.Destination.CountryIso" value="GB">
                            <input type="hidden" name="Destination.Postcode" data-bind="value:$parent.Destination.Postcode" value="">
                            <input type="hidden" name="Destination.RegionId" data-bind="value:$parent.Destination.RegionId">
                            <input type="hidden" name="JourneyType" data-bind="value:$parent.JourneyType" value="OneWay">
                            <input type="hidden" name="TotalBags" data-bind="value:$parent.TotalBags" value="1">
                            <input type="hidden" name="DeliveryMethodType" data-bind="value:DeliveryMethodType" value="2">
                            <button type="submit" class="btn btn-primary btn-lg">Book Now</button>
                        </form>
                    </div>
                </div>
                <div class="mt-2 alert alert-danger" role="alert">
                    <strong>Important!</strong> If sending from an address with a daily DHL Packet collection, do not hand the bag to that driver.
                </div>
            </div>
    </div>

	<div class="entry-content">
    	<div class="container">
            <div class="row">
            	<h3 class="orangebgheader">What You Can Send</h3>
                <table class="table table-responsive table-hover">
                	<tbody>
                        <tr>
                            <th scope="row" class="hidden-sm-down biggreencheck"><i class="fa fa-check" aria-hidden="true"></i></th>
                            <td>Suitcases and Bags</td>
                            <td>We ship all types of suitcases and rucksacks! If you're a heavy packer ensure your bag is designed to hold the weight, also secure all straps and handles. All quotes are based on size and weight check if your suitcase fits within our generous standard allowance.</td>
                        </tr>
                        <tr>
                            <th scope="row" class="hidden-sm-down biggreencheck"><i class="fa fa-check" aria-hidden="true"></i></th>
                            <td>Boxes</td>
                            <td>Yes! We send boxes, but only use sturdy double walled cardboard boxes. If a 5kg express rate is available on your route, only boxes and packages which can be measured accurately are permitted on that service. Small carry-ons, backpacks or any other items with straps or protruding parts are not permitted on the 5kg express service.</td>
                        </tr>
                        <tr>
                            <th scope="row" class="hidden-sm-down biggreencheck"><i class="fa fa-check" aria-hidden="true"></i></th>
                            <td>Golf Bags</td>
                            <td>No need to play with borrowed clubs ever again! On international services golf bags under 120cm will be charged at our standard suitcase rates, if they exceed 120cm a £25 + VAT fee will apply. Within the UK we ship sports equipment up to 150cm with no extra fee when it is also within our 30kg rate's weight and size limits. More info on packaging and sending golf clubs.</td>
                        </tr>
                        <tr>
                            <th scope="row" class="hidden-sm-down biggreencheck"><i class="fa fa-check" aria-hidden="true"></i></th>
                            <td>Ski Bags</td>
                            <td>We can accept ski gear up to 220cm, if your bag is over 120cm a £25 + VAT fee will apply. Within the UK Ski equipment up to 150cm won't trigger this charge when the bag is within the weight and size allowance of our up to 30kg rate. More info on packaging and sending skis.</td>
                        </tr>
                        <tr>
                            <th scope="row" class="hidden-sm-down biggreencheck"><i class="fa fa-check" aria-hidden="true"></i></th>
                            <td>Bicycles</td>
                            <td>Most bike boxes take up more space than a suitcase, check out how we charge for large items or click "Book Now" to enter dimensions and receive a custom quote. More info on packaging and sending a bike.</td>
                        </tr>
                        <tr>
                            <th scope="row" class="hidden-sm-down bigredcross"><i class="fa fa-times" aria-hidden="true"></i></th>
                            <td>Not Allowed</td>
                            <td>Sorry, we can't accept plastic bags (including laundry bags) or plastic boxes. There's also a few things, such as aerosols, which we can't accept inside luggage. Our rules on toiletries vary by route; view our prohibited items list for your destination.</td>
                        </tr>
                	</tbody>
                </table>
            </div>
        </div>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
    
	</footer><!-- .entry-footer -->

</article><!-- #post-## -->