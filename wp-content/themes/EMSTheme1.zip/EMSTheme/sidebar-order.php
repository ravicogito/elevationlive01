<?php
/**
 * The right sidebar containing the main widget area.
 *
 * @package understrap
 */
?>

<div class="col-md-3 widget-area" id="right-sidebar" role="complementary">
	<div id="basket">
    	<h2 class="orangebgheader">Order Summary</h2>
        <div id="ordersummary" class="p-2">
        	<div class="row">
            	<div class="col">
                    <span class="order-summary-value">UK <i class="fa fa-arrow-right orangetext"></i> </span>
                    <span class="order-summary-value">Spain</span>
                </div>
            </div>
            <div class="row mt-2">
            	<div class="col">
            		<div class="order-summary-label orangetext">Items</div>
                    <div class="order-summary-value pl-2">
                        <div>
                            1 - £109.00
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-2">
            	<div class="col">
            		<div class="order-summary-label orangetext">Add-ons</div>
                    <table class="table table-sm order-summary-addons">
                        <tbody>
                            <tr>
                                <td>FREE</td>
                                <td class="text-muted">£125.00 Cover</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row text-center">
            	<div class="col">
                	<div class="order-summary-label order-summary-total orangetext"><strong>Total</strong></div>
                    <div class="order-summary-value order-summary-total">£109.00</div>
                    <div class="order-summary-total-to-pay">£109.00</div>
                    <div class="order-summary-currency-code text-muted">GBP</div>
            	</div>
            </div>
        </div>
    </div>
</div><!-- #secondary -->

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script
	src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"
	integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="
	crossorigin="anonymous">
</script>
<script>
	$( function() {
		$( "#datepicker" ).datepicker({
			numberOfMonths: 2,
			showButtonPanel: true,
			dateFormat: 'DD dx MM, yy',
			minDate: 0,
			beforeShowDay: $.datepicker.noWeekends,
			onSelect: function(dateText, inst) {
				var arrOrd = new Array('0','st','nd','rd','th','th','th','th','th','th','th','th','th','th','th','th','th','th','th','th','th','st','nd','rd','th','th','th','th','th','th','th','st');
				var day = Number(inst.selectedDay);
				var suffix = arrOrd[day];       
				$(this).val($(this).val().replace(inst.selectedDay+"x",inst.selectedDay+suffix));
				$('#collectiondate').text($(this).val().replace(inst.selectedDay+"x",inst.selectedDay+suffix));
				
			}
		});
	});

	$=jQuery.noConflict();
	window.onload=function(){
		var sidebar = $('#right-sidebar'),
			basket = $('#basket'),
			startPosition = sidebar.offset().top,
			stopPosition = $('#wrapper-footer').offset().top - basket.outerHeight();
		
		$(document).scroll(function () {
			if ( $(window).width() > 1200) {  
				//stick nav to top of page
				var y = $(this).scrollTop();
			
				if (y > startPosition) {
					basket.addClass('stickysticky');
					if (y > stopPosition) {
						basket.css('top', stopPosition - y);
					} else {
						basket.css('top', 0);
					}
				} else {
					basket.removeClass('stickysticky');
				} 
			}
		});
	}
	
	$(document).ready(function(){
		$('#addressType').on('change', function() {
			if ( this.value == '2' ){
				$("#ifApartment").show();
			}
			else {
				$("#ifApartment").hide();
			}
			if ( this.value == '3' ){
				$("#ifBusiness").show();
			}
			else {
				$("#ifBusiness").hide();
			}
			if ( this.value == '4' ){
				$("#ifUni").show();
			}
			else {
				$("#ifUni").hide();
			}
			if ( this.value == '5' ){
				$("#ifHotel").show();
				$("#ifHotelName").show();
				$("#notHotelName").hide();
			}
			else {
				$("#ifHotel").hide();
				$("#ifHotelName").hide();
				$("#notHotelName").show();
			}
		});
		$('#addressType2').on('change', function() {
			if ( this.value == '2' ){
				$("#ifApartment2").show();
			}
			else {
				$("#ifApartment2").hide();
			}
			if ( this.value == '3' ){
				$("#ifBusiness2").show();
			}
			else {
				$("#ifBusiness2").hide();
			}
			if ( this.value == '4' ){
				$("#ifUni2").show();
			}
			else {
				$("#ifUni2").hide();
			}
			if ( this.value == '5' ){
				$("#ifHotel2").show();
				$("#ifHotelName2").show();
				$("#notHotelName2").hide();
			}
			else {
				$("#ifHotel2").hide();
				$("#ifHotelName2").hide();
				$("#notHotelName2").show();
			}
		});
		$('#addressType3').on('change', function() {
			if ( this.value == '5' ){
				$("#ifHotelName3").show();
				$("#notHotelName3").hide();
			}
			else {
				$("#ifHotelName3").hide();
				$("#notHotelName3").show();
			}
		});
		$('#itemType').on('change', function() {
			if ( this.value == '2' ){
				$("#ifBox").show();
			}
			else {
				$("#ifBox").hide();
			}
		});
		$('#yesBuzzer').on('change', function() {
			$("#ifBuzzer").show();
			$("#radiobuzzer").hide();
		});
		$('#yesBuzzer2').on('change', function() {
			$("#ifBuzzer2").show();
			$("#radiobuzzer2").hide();
		});
		$('#labelHolders').on('change', function() {
			if ( this.value == '2' ){
				$("#labelHoldersAlert").show();
			}
			else {
				$("#labelHoldersAlert").hide();
			}
		});
		$('#postMyLabels').on('change', function() {
			if ( this.value == '2' ){
				$("#postMyLabelsAlert").show();
			}
			else {
				$("#postMyLabelsAlert").hide();
			}
		});
		$('#labelHolders, #postMyLabels').on('change', function() {
			if ( $('#labelHolders').val() == '1' || $('#postMyLabels').val() == '1' ){
				$("#labelPostage").show();
			}
			else {
				$("#labelPostage").hide();
			}
		});
		$('#NewAddy').on('change', function() {
			$("#postageLabelsForm").show();
		});
		$('#ExistingAddy').on('change', function() {
			$("#postageLabelsForm").hide();
		});
		$('#accountYes').on('change', function() {
			$("#accountYesForm").show();
			$("#accountAlreadyForm").hide();
		});
		$('#accountAlready').on('change', function() {
			$("#accountYesForm").hide();
			$("#accountAlreadyForm").show();
		});
	});
</script>