<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package understrap
 */

$container = get_theme_mod( 'understrap_container_type' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="<?php bloginfo( 'name' ); ?> - <?php bloginfo( 'description' ); ?>">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="hfeed site" id="page">

	<!-- ******************* The Navbar Area ******************* -->
	<div class="wrapper-fluid wrapper-navbar" id="wrapper-navbar">

		<a class="skip-link screen-reader-text sr-only" href="#content"><?php _e( 'Skip to content','understrap' ); ?></a>
        <div id="topnavbar">
            <div class="container">
                <ul class="nav justify-content-end">
                    <li id="menu-item-18" class="menu-item nav-item"><a title="Login" href="http://www.pathwebdesign.co.uk/" class="nav-link">Login</a></li>
                    <li style="padding-top:.5em">|</li>
                    <li id="menu-item-18" class="menu-item nav-item"><a title="Register" href="http://www.pathwebdesign.co.uk/" class="nav-link">Register</a></li>
                    <li style="padding-top:.5em">|</li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="currencyDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">£ GBP</a>
                        <div class="dropdown-menu" aria-labelledby="currencyDropdown">
                            <a class="dropdown-item" href="#">£ British Pound</a>
                            <a class="dropdown-item" href="#">€ Euro</a>
                            <a class="dropdown-item" href="#">$ US Dollar</a>
                            <a class="dropdown-item" href="#">$ Australian Dollar</a>
                            <a class="dropdown-item" href="#">kr Swedish Krona</a>
                        </div>
                    </li>
                    <li style="padding-top:.5em">|</li>
                    <li class="nav-item dropdown">
                    	<a class="nav-link dropdown-toggle" href="#" id="countryDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">UK - Mainland</a>
                    	<div class="dropdown-menu" aria-labelledby="countryDropdown">
                    		<h5 class="dropdown-item">Most Popular</h5>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Mainland</a>
                            <a class="dropdown-item" value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</a>
                            <a class="dropdown-item" value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</a>
                            <a class="dropdown-item" value="ES" data-alt="">Spain</a>
                            <a class="dropdown-item" value="US" data-alt="US USA America">United States</a>
                            <a class="dropdown-item" value="AU" data-alt="">Australia</a>
                            <a class="dropdown-item" value="FR" data-alt="">France</a>
                            <a class="dropdown-item" value="DE" data-alt="">Germany</a>
                            <a class="dropdown-item" value="IT" data-alt="">Italy</a>
                            <a class="dropdown-item" value="IE" data-alt="">Ireland</a>
                            <div class="dropdown-divider"></div>
                    		<h5 class="dropdown-item" class="dropdown-item">A-Z</h5>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" value="AF" data-alt="">Afghanistan</a>
                            <a class="dropdown-item" value="DZ" data-alt="">Algeria</a>
                            <a class="dropdown-item" value="AS" data-alt="">American Samoa</a>
                            <a class="dropdown-item" value="AO" data-alt="">Angola</a>
                            <a class="dropdown-item" value="AI" data-alt="">Anguilla</a>
                            <a class="dropdown-item" value="AM" data-alt="">Armenia</a>
                            <a class="dropdown-item" value="AW" data-alt="">Aruba</a>
                            <a class="dropdown-item" value="AU" data-alt="">Australia</a>
                            <a class="dropdown-item" value="AT" data-alt="">Austria</a>
                            <a class="dropdown-item" value="AZ" data-alt="">Azerbaijan</a>
                            <a class="dropdown-item" value="BS" data-alt="">Bahamas</a>
                            <a class="dropdown-item" value="BH" data-alt="">Bahrain</a>
                            <a class="dropdown-item" value="BD" data-alt="">Bangladesh</a>
                            <a class="dropdown-item" value="BB" data-alt="">Barbados</a>
                            <a class="dropdown-item" value="BE" data-alt="">Belgium</a>
                            <a class="dropdown-item" value="BZ" data-alt="">Belize</a>
                            <a class="dropdown-item" value="BJ" data-alt="">Benin</a>
                            <a class="dropdown-item" value="BM" data-alt="">Bermuda</a>
                            <a class="dropdown-item" value="BT" data-alt="">Bhutan</a>
                            <a class="dropdown-item" value="BO" data-alt="">Bolivia</a>
                            <a class="dropdown-item" value="BW" data-alt="">Botswana</a>
                            <a class="dropdown-item" value="BR" data-alt="">Brazil</a>
                            <a class="dropdown-item" value="BN" data-alt="">Brunei Darussalam</a>
                            <a class="dropdown-item" value="BG" data-alt="">Bulgaria</a>
                            <a class="dropdown-item" value="BF" data-alt="">Burkina Faso</a>
                            <a class="dropdown-item" value="BI" data-alt="">Burundi</a>
                            <a class="dropdown-item" value="KH" data-alt="">Cambodia</a>
                            <a class="dropdown-item" value="CM" data-alt="">Cameroon</a>
                            <a class="dropdown-item" value="CA" data-alt="">Canada</a>
                            <a class="dropdown-item" value="CV" data-alt="">Cape Verde</a>
                            <a class="dropdown-item" value="CF" data-alt="">Central African Republic</a>
                            <a class="dropdown-item" value="TD" data-alt="">Chad</a>
                            <a class="dropdown-item" value="CL" data-alt="">Chile</a>
                            <a class="dropdown-item" value="CO" data-alt="">Colombia</a>
                            <a class="dropdown-item" value="CG" data-alt="">Congo</a>
                            <a class="dropdown-item" value="CK" data-alt="">Cook Islands</a>
                            <a class="dropdown-item" value="CR" data-alt="">Costa Rica</a>
                            <a class="dropdown-item" value="CI" data-alt="">Cote D'Ivoire</a>
                            <a class="dropdown-item" value="HR" data-alt="">Croatia</a>
                            <a class="dropdown-item" value="CU" data-alt="">Cuba</a>
                            <a class="dropdown-item" value="CY" data-alt="">Cyprus</a>
                            <a class="dropdown-item" value="CZ" data-alt="">Czech Republic</a>
                            <a class="dropdown-item" value="DK" data-alt="">Denmark</a>
                            <a class="dropdown-item" value="DJ" data-alt="">Djibouti</a>
                            <a class="dropdown-item" value="DM" data-alt="">Dominica</a>
                            <a class="dropdown-item" value="DO" data-alt="">Dominican Republic</a>
                            <a class="dropdown-item" value="EC" data-alt="">Ecuador</a>
                            <a class="dropdown-item" value="EG" data-alt="">Egypt</a>
                            <a class="dropdown-item" value="SV" data-alt="">El Salvador</a>
                            <a class="dropdown-item" value="GQ" data-alt="">Equatorial Guinea</a>
                            <a class="dropdown-item" value="ER" data-alt="">Eritrea</a>
                            <a class="dropdown-item" value="EE" data-alt="">Estonia</a>
                            <a class="dropdown-item" value="ET" data-alt="">Ethiopia</a>
                            <a class="dropdown-item" value="FK" data-alt="">Falkland Islands (Malvinas)</a>
                            <a class="dropdown-item" value="FJ" data-alt="">Fiji</a>
                            <a class="dropdown-item" value="FI" data-alt="">Finland</a>
                            <a class="dropdown-item" value="FR" data-alt="">France</a>
                            <a class="dropdown-item" value="GF" data-alt="">French Guiana</a>
                            <a class="dropdown-item" value="GA" data-alt="">Gabon</a>
                            <a class="dropdown-item" value="GM" data-alt="">Gambia</a>
                            <a class="dropdown-item" value="GE" data-alt="">Georgia</a>
                            <a class="dropdown-item" value="DE" data-alt="">Germany</a>
                            <a class="dropdown-item" value="GH" data-alt="">Ghana</a>
                            <a class="dropdown-item" value="GR" data-alt="">Greece</a>
                            <a class="dropdown-item" value="GD" data-alt="">Grenada</a>
                            <a class="dropdown-item" value="GP" data-alt="">Guadeloupe</a>
                            <a class="dropdown-item" value="GU" data-alt="">Guam</a>
                            <a class="dropdown-item" value="GT" data-alt="">Guatemala</a>
                            <a class="dropdown-item" value="GG" data-alt="UK United Kingdom England Great Britain Channel Islands">Guernsey</a>
                            <a class="dropdown-item" value="GW" data-alt="">Guinea-Bissau</a>
                            <a class="dropdown-item" value="GY" data-alt="">Guyana</a>
                            <a class="dropdown-item" value="HT" data-alt="">Haiti</a>
                            <a class="dropdown-item" value="HN" data-alt="">Honduras</a>
                            <a class="dropdown-item" value="HK" data-alt="">Hong Kong</a>
                            <a class="dropdown-item" value="HU" data-alt="">Hungary</a>
                            <a class="dropdown-item" value="IS" data-alt="">Iceland</a>
                            <a class="dropdown-item" value="IN" data-alt="">India</a>
                            <a class="dropdown-item" value="ID" data-alt="">Indonesia</a>
                            <a class="dropdown-item" value="IR" data-alt="">Iran, Islamic Republic of</a>
                            <a class="dropdown-item" value="IQ" data-alt="">Iraq</a>
                            <a class="dropdown-item" value="IE" data-alt="">Ireland</a>
                            <a class="dropdown-item" value="IL" data-alt="">Israel</a>
                            <a class="dropdown-item" value="IT" data-alt="">Italy</a>
                            <a class="dropdown-item" value="JM" data-alt="">Jamaica</a>
                            <a class="dropdown-item" value="JP" data-alt="">Japan</a>
                            <a class="dropdown-item" value="JE" data-alt="UK United Kingdom England Great Britain Channel Islands">Jersey</a>
                            <a class="dropdown-item" value="JO" data-alt="">Jordan</a>
                            <a class="dropdown-item" value="KZ" data-alt="">Kazakhstan</a>
                            <a class="dropdown-item" value="KE" data-alt="">Kenya</a>
                            <a class="dropdown-item" value="KI" data-alt="">Kiribati</a>
                            <a class="dropdown-item" value="KR" data-alt="South Korea">Korea, Republic of</a>
                            <a class="dropdown-item" value="KW" data-alt="">Kuwait</a>
                            <a class="dropdown-item" value="KG" data-alt="">Kyrgyzstan</a>
                            <a class="dropdown-item" value="LV" data-alt="">Latvia</a>
                            <a class="dropdown-item" value="LB" data-alt="">Lebanon</a>
                            <a class="dropdown-item" value="LS" data-alt="">Lesotho</a>
                            <a class="dropdown-item" value="LR" data-alt="">Liberia</a>
                            <a class="dropdown-item" value="LT" data-alt="">Lithuania</a>
                            <a class="dropdown-item" value="LU" data-alt="">Luxembourg</a>
                            <a class="dropdown-item" value="MO" data-alt="">Macao</a>
                            <a class="dropdown-item" value="MG" data-alt="">Madagascar</a>
                            <a class="dropdown-item" value="MW" data-alt="">Malawi</a>
                            <a class="dropdown-item" value="MY" data-alt="">Malaysia</a>
                            <a class="dropdown-item" value="MV" data-alt="">Maldives</a>
                            <a class="dropdown-item" value="MT" data-alt="">Malta</a>
                            <a class="dropdown-item" value="MH" data-alt="">Marshall Islands</a>
                            <a class="dropdown-item" value="MQ" data-alt="">Martinique</a>
                            <a class="dropdown-item" value="MR" data-alt="">Mauritania</a>
                            <a class="dropdown-item" value="MU" data-alt="">Mauritius</a>
                            <a class="dropdown-item" value="YT" data-alt="">Mayotte</a>
                            <a class="dropdown-item" value="MX" data-alt="">Mexico</a>
                            <a class="dropdown-item" value="MC" data-alt="">Monaco</a>
                            <a class="dropdown-item" value="MN" data-alt="">Mongolia</a>
                            <a class="dropdown-item" value="MS" data-alt="">Montserrat</a>
                            <a class="dropdown-item" value="MA" data-alt="">Morocco</a>
                            <a class="dropdown-item" value="MZ" data-alt="">Mozambique</a>
                            <a class="dropdown-item" value="MM" data-alt="">Myanmar</a>
                            <a class="dropdown-item" value="NA" data-alt="">Namibia</a>
                            <a class="dropdown-item" value="NR" data-alt="">Nauru</a>
                            <a class="dropdown-item" value="NP" data-alt="">Nepal</a>
                            <a class="dropdown-item" value="NL" data-alt="">Netherlands</a>
                            <a class="dropdown-item" value="AN" data-alt="">Netherlands Antilles</a>
                            <a class="dropdown-item" value="NC" data-alt="">New Caledonia</a>
                            <a class="dropdown-item" value="NZ" data-alt="">New Zealand</a>
                            <a class="dropdown-item" value="NI" data-alt="">Nicaragua</a>
                            <a class="dropdown-item" value="NE" data-alt="">Niger</a>
                            <a class="dropdown-item" value="NG" data-alt="">Nigeria</a>
                            <a class="dropdown-item" value="NU" data-alt="">Niue</a>
                            <a class="dropdown-item" value="NO" data-alt="">Norway</a>
                            <a class="dropdown-item" value="OM" data-alt="">Oman</a>
                            <a class="dropdown-item" value="PK" data-alt="">Pakistan</a>
                            <a class="dropdown-item" value="PW" data-alt="">Palau</a>
                            <a class="dropdown-item" value="PA" data-alt="">Panama</a>
                            <a class="dropdown-item" value="PG" data-alt="">Papua New Guinea</a>
                            <a class="dropdown-item" value="PY" data-alt="">Paraguay</a>
                            <a class="dropdown-item" value="PH" data-alt="">Philippines</a>
                            <a class="dropdown-item" value="PL" data-alt="">Poland</a>
                            <a class="dropdown-item" value="PT" data-alt="">Portugal</a>
                            <a class="dropdown-item" value="PR" data-alt="">Puerto Rico</a>
                            <a class="dropdown-item" value="QA" data-alt="">Qatar</a>
                            <a class="dropdown-item" value="RE" data-alt="">Reunion</a>
                            <a class="dropdown-item" value="RO" data-alt="">Romania</a>
                            <a class="dropdown-item" value="RW" data-alt="">Rwanda</a>
                            <a class="dropdown-item" value="LC" data-alt="">Saint Lucia</a>
                            <a class="dropdown-item" value="WS" data-alt="">Samoa</a>
                            <a class="dropdown-item" value="ST" data-alt="">Sao Tome and Principe</a>
                            <a class="dropdown-item" value="SA" data-alt="">Saudi Arabia</a>
                            <a class="dropdown-item" value="SN" data-alt="">Senegal</a>
                            <a class="dropdown-item" value="SC" data-alt="">Seychelles</a>
                            <a class="dropdown-item" value="SL" data-alt="">Sierra Leone</a>
                            <a class="dropdown-item" value="SG" data-alt="">Singapore</a>
                            <a class="dropdown-item" value="SK" data-alt="">Slovakia</a>
                            <a class="dropdown-item" value="SI" data-alt="">Slovenia</a>
                            <a class="dropdown-item" value="SB" data-alt="">Solomon Islands</a>
                            <a class="dropdown-item" value="SO" data-alt="">Somalia</a>
                            <a class="dropdown-item" value="ZA" data-alt="">South Africa</a>
                            <a class="dropdown-item" value="ES" data-alt="">Spain</a>
                            <a class="dropdown-item" value="SD" data-alt="">Sudan</a>
                            <a class="dropdown-item" value="SR" data-alt="">Suriname</a>
                            <a class="dropdown-item" value="SZ" data-alt="">Swaziland</a>
                            <a class="dropdown-item" value="SE" data-alt="">Sweden</a>
                            <a class="dropdown-item" value="CH" data-alt="">Switzerland</a>
                            <a class="dropdown-item" value="SY" data-alt="">Syrian Arab Republic</a>
                            <a class="dropdown-item" value="TW" data-alt="">Taiwan, Province of China</a>
                            <a class="dropdown-item" value="TJ" data-alt="">Tajikistan</a>
                            <a class="dropdown-item" value="TZ" data-alt="">Tanzania, United Republic of</a>
                            <a class="dropdown-item" value="TH" data-alt="">Thailand</a>
                            <a class="dropdown-item" value="TG" data-alt="">Togo</a>
                            <a class="dropdown-item" value="TO" data-alt="">Tonga</a>
                            <a class="dropdown-item" value="TT" data-alt="">Trinidad and Tobago</a>
                            <a class="dropdown-item" value="TN" data-alt="">Tunisia</a>
                            <a class="dropdown-item" value="TC" data-alt="">Turks and Caicos Islands</a>
                            <a class="dropdown-item" value="TV" data-alt="">Tuvalu</a>
                            <a class="dropdown-item" value="UG" data-alt="">Uganda</a>
                            <a class="dropdown-item" value="GB-HAI" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Highlands &amp; Islands</a>
                            <a class="dropdown-item" value="GB" data-alt="United Kingdom England Wales Scotland Ireland Northern Ireland NI Great Britain">UK - Mainland</a>
                            <a class="dropdown-item" value="GB-NI" data-alt="United Kingdom England Ireland Northern Ireland NI Great Britain">UK - Northern Ireland</a>
                            <a class="dropdown-item" value="AE" data-alt="uae">United Arab Emirates</a>
                            <a class="dropdown-item" value="US" data-alt="US USA America">United States</a>
                            <a class="dropdown-item" value="UY" data-alt="">Uruguay</a>
                            <a class="dropdown-item" value="UZ" data-alt="">Uzbekistan</a>
                            <a class="dropdown-item" value="VU" data-alt="">Vanuatu</a>
                            <a class="dropdown-item" value="VE" data-alt="">Venezuela</a>
                            <a class="dropdown-item" value="VN" data-alt="">Viet Nam</a>
                            <a class="dropdown-item" value="VG" data-alt="">Virgin Islands, British</a>
                            <a class="dropdown-item" value="ZM" data-alt="">Zambia</a>
                            <a class="dropdown-item" value="ZW" data-alt="">Zimbabwe</a>
                        </div>
                	</li>
                </ul>
            </div>
		</div>
		<nav id="primaryNav" class="navbar navbar-toggleable-md navbar-light">
            
			<?php if ( 'container' == $container ) : ?>
            <div class="container">
            <?php endif; ?>
            
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
                
                <!-- Your site title as branding in the menu -->
                <?php if ( ! has_custom_logo() ) { ?>
    
                    <?php if ( is_front_page() && is_home() ) : ?>
    
                        <h1 class="navbar-brand mb-0"><?php bloginfo( 'name' ); ?></h1>
                        
                    <?php else : ?>
    
                        <a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    
                    <?php endif; ?>
                
                <?php } else {
                    the_custom_logo();
                } ?><!-- end custom logo -->
    
                <!-- The WordPress Menu goes here -->
                <?php /*wp_nav_menu(
                    array(
                        'theme_location'  => 'primary',
                        'container_class' => 'collapse navbar-collapse',
                        'container_id'    => 'navbarNavDropdown',
                        'menu_class'      => 'navbar-nav',
                        'fallback_cb'     => '',
                        'menu_id'         => 'main-menu',
                        'walker'          => new WP_Bootstrap_Navwalker(),
                    )
                ); */ ?>
                
                <div id="navbarNavDropdown" class="collapse navbar-collapse">
                    <ul id="main-menu" class="navbar-nav">
                        <li id="menu-item-18" class="menu-item nav-item"><a title="Quote and Book" href="http://www.pathwebdesign.co.uk/quote/" class="nav-link orangebutton">Quote &amp; Book</a></li>

                        <li id="menu-item-18" class="menu-item nav-item"><a title="Contact Us" href="http://www.pathwebdesign.co.uk/contact-us/" class="nav-link">Get In Touch</a></li>
                        <li id="menu-item-18" class="menu-item nav-item"><a title="FAQ" href="http://www.pathwebdesign.co.uk/faq/" class="nav-link">FAQ</a></li>
                        <li id="menu-item-18" class="menu-item nav-item"><a title="Destinations" href="http://www.pathwebdesign.co.uk/baggage-shipping-destinations/" class="nav-link">Destinations</a></li>
                        <li id="menu-item-18" class="menu-item nav-item"><a title="How It Works" href="http://www.pathwebdesign.co.uk/how-it-works/" class="nav-link">How It Works</a></li>
                    </ul>
                </div>
                                
            <?php if ( 'container' == $container ) : ?>
            </div><!-- .container -->
            <?php endif; ?>

		</nav><!-- .site-navigation -->

	</div><!-- .wrapper-navbar end -->